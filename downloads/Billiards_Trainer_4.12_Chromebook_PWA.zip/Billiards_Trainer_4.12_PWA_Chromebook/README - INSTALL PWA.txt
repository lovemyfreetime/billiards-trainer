BILLIARDS TRAINER 4.12 — CHROMEBOOK PWA EDITION

WHAT THIS VERSION DOES
- Installs as a standalone Chromebook web app.
- Once launched from the Chromebook launcher/shelf, it has NO normal Chrome address bar or tabs.
- Works offline after the first successful load/install.
- Uses the same Billiards Trainer 4.12 Virtual Diamonds code.
- Uses the refreshed glossy Billiards Trainer icon.

IMPORTANT
A PWA cannot be installed directly from a file:// HTML page. Chrome requires it to be opened once from http://localhost or HTTPS so the service worker can register.

ONE-TIME INSTALL ON CHROMEBOOK
1. Extract this ZIP into Linux files, or copy this entire folder into Linux files.
2. Open Terminal.
3. Change into this folder. Example:
   cd ~/Billiards_Trainer_4.12_PWA_Chromebook
4. Run:
   ./start-pwa-server.sh
   If ChromeOS says permission denied, run:
   chmod +x start-pwa-server.sh
   ./start-pwa-server.sh
5. In Chrome open:
   http://127.0.0.1:4120/
6. After the trainer loads, use either:
   - the green INSTALL CHROMEBOOK APP button if it appears, OR
   - Chrome menu > Install Billiards Trainer 4.12 for Chromebook
7. Launch Billiards Trainer from the Chromebook launcher. It opens in a standalone app window with no normal address bar/tabs.
8. Pin it to the shelf if desired.

OFFLINE
After installation and the first complete load, the service worker caches the trainer, manifest and icons. The installed app can then continue to open from its cached local copy.

IN-APP TITLE
Billiards Trainer
Chromebook Edition
