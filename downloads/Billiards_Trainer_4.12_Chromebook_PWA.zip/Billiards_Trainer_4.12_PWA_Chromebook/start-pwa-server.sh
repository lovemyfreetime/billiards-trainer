#!/bin/bash
cd "$(dirname "$0")"
echo "Billiards Trainer PWA server running at http://127.0.0.1:4120/"
echo "Leave this Terminal open during the one-time install."
python3 -m http.server 4120 --bind 127.0.0.1
