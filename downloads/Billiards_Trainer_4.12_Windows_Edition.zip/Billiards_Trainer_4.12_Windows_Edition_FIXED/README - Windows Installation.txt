BILLIARDS TRAINER 4.12 - WINDOWS EDITION

INSTALL
1. Extract this ZIP to a normal folder.
2. Double-click "Install Billiards Trainer.cmd".
3. It installs to your user Local AppData folder, creates Desktop and Start-menu shortcuts, and launches the trainer.

The trainer opens in Microsoft Edge/Chrome app mode with no address bar, tabs, or bookmarks bar.
It works offline from the local HTML file.

PORTABLE MODE
Double-click "Launch Portable - No Install.cmd" to run directly from this folder without creating shortcuts.

UNINSTALL
Use the Start-menu shortcut "Uninstall Billiards Trainer 4.12".

FIXED BUILD
This package fixes the PowerShell shortcut-creation error from the first Windows package.
