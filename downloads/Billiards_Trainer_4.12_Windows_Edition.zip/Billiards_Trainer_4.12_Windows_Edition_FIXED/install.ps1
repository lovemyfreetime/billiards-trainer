$ErrorActionPreference = 'Stop'
$AppName = 'Billiards Trainer 4.12 for Windows'
$SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = Join-Path $env:LOCALAPPDATA 'BilliardsTrainer412Windows'

$edgeCandidates = @(
  (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
) | Where-Object { $_ -and (Test-Path $_) }

$browser = $edgeCandidates | Select-Object -First 1
if (-not $browser) {
  $chromeCandidates = @(
    (Join-Path ${env:ProgramFiles} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
  ) | Where-Object { $_ -and (Test-Path $_) }
  $browser = $chromeCandidates | Select-Object -First 1
}
if (-not $browser) {
  Add-Type -AssemblyName PresentationFramework
  [System.Windows.MessageBox]::Show('Microsoft Edge or Google Chrome was not found. Windows 11 normally includes Edge.','Billiards Trainer') | Out-Null
  exit 1
}

New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item (Join-Path $SourceDir 'BilliardsTrainer_4.12_Windows.html') (Join-Path $InstallDir 'BilliardsTrainer_4.12_Windows.html') -Force
Copy-Item (Join-Path $SourceDir 'BilliardsTrainer.ico') (Join-Path $InstallDir 'BilliardsTrainer.ico') -Force
Copy-Item (Join-Path $SourceDir 'billiards-trainer-icon.png') (Join-Path $InstallDir 'billiards-trainer-icon.png') -Force
Copy-Item (Join-Path $SourceDir 'uninstall.ps1') (Join-Path $InstallDir 'uninstall.ps1') -Force

$htmlPath = Join-Path $InstallDir 'BilliardsTrainer_4.12_Windows.html'
$uri = 'file:///' + (($htmlPath -replace '\\','/') -replace ' ','%20')
$launchArguments = '--app="' + $uri + '" --start-maximized'
$icon = Join-Path $InstallDir 'BilliardsTrainer.ico'

$ws = New-Object -ComObject WScript.Shell
function New-AppShortcut([string]$Path) {
  $sc = $ws.CreateShortcut($Path)
  $sc.TargetPath = $browser
  $sc.Arguments = $launchArguments
  $sc.WorkingDirectory = $InstallDir
  $sc.IconLocation = "$icon,0"
  $sc.Description = 'Billiards Trainer 4.12 - Windows Edition'
  $sc.Save()
}

$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
New-AppShortcut (Join-Path $desktop ($AppName + '.lnk'))
New-AppShortcut (Join-Path $startMenu ($AppName + '.lnk'))

# Uninstall shortcut in Start menu.
$unSc = $ws.CreateShortcut((Join-Path $startMenu 'Uninstall Billiards Trainer 4.12.lnk'))
$unSc.TargetPath = 'powershell.exe'
$unSc.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + (Join-Path $InstallDir 'uninstall.ps1') + '"'
$unSc.WorkingDirectory = $InstallDir
$unSc.IconLocation = "$icon,0"
$unSc.Save()

Start-Process -FilePath $browser -ArgumentList $launchArguments
