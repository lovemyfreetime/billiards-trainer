@echo off
setlocal
set "HTML=%~dp0BilliardsTrainer_4.12_Windows.html"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
if not exist "%EDGE%" (
  echo Microsoft Edge or Google Chrome was not found.
  pause
  exit /b 1
)
for %%I in ("%HTML%") do set "FULL=%%~fI"
set "URI=file:///%FULL:\=/%"
start "" "%EDGE%" --app="%URI: =%%20%" --start-maximized
