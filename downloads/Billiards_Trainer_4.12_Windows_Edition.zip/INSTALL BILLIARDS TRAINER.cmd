@echo off
setlocal
attrib +h "%~dp0_APP_FILES_DO_NOT_OPEN" >nul 2>&1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0_APP_FILES_DO_NOT_OPEN\install.ps1"
if errorlevel 1 pause
