Support files for Billiards Trainer 4.12 Windows Edition.
Normal users should return to the parent folder and double-click INSTALL BILLIARDS TRAINER.cmd.
