$ErrorActionPreference = 'SilentlyContinue'
$AppName = 'Billiards Trainer 4.12 for Windows'
$InstallDir = Join-Path $env:LOCALAPPDATA 'BilliardsTrainer412Windows'
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
Remove-Item (Join-Path $desktop ($AppName + '.lnk')) -Force
Remove-Item (Join-Path $startMenu ($AppName + '.lnk')) -Force
Remove-Item (Join-Path $startMenu 'Uninstall Billiards Trainer 4.12.lnk') -Force
Start-Sleep -Milliseconds 400
Remove-Item $InstallDir -Recurse -Force
