Billiards Play — Offline

Extract the entire folder and open play.html. All 20 real-table games, Tournament Play, drill tracking, shot clock and calibration are included. No internet is needed. Browser storage availability under file URLs varies by browser: use the Android Play app or existing Windows Local Host for reliable saves and private player connections. This web package cannot create a hotspot or supply offline speech recognition. Android Play uses an available on-device speech service; it never switches to cloud recognition. Trainer and Zen are separate packages.
